# SecureLocker
A file's encrypt application by RSA key under OPENSSL

## Building


