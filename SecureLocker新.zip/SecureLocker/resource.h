﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 SecureLocker.rc 使用
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_FRIEND_IMPORTPAGE1          102
#define IDD_IMPORTKEY_PAGE1             106
#define IDR_MAINFRAME                   128
#define IDR_SecureLockerTYPE            130
#define IDD_DIALOG_FRIENDKEYS           310
#define IDD_PROPPAGE_IMPORTKEY2         311
#define IDD_FRIEND_IMPORTPAGE2          311
#define IDR_MENUPOP                     312
#define IDD_EXPORTKEY_PAGE1             312
#define IDD_IMPORTKEY_PAGE2             313
#define IDD_EXPORTKEY_PAGE2             314
#define IDD_DIALOG_KEYGEN               316
#define IDD_DIALOG_ENCRYPT              319
#define IDD_DIALOG_KEYMGR               320
#define IDD_DIALOG_DECRYPT              321
#define IDD_DIALOG_PASSWORD             322
#define IDD_EREASER_DIALOG              323
#define IDB_BITMAP_USER                 324
#define IDC_LIST_KEYS                   1000
#define IDC_BUTTON_GENKEY               1001
#define IDC_BUTTON_ADDKEY               1002
#define IDC_BUTTON_REGEN                1003
#define IDC_BUTTON_DELKEY               1003
#define IDC_BUTTON_LOAD2                1004
#define IDC_BUTTON_EXPORT               1005
#define IDC_BUTTON_IMPORT2              1006
#define IDC_EDIT_FILENAME               1008
#define IDC_BUTTON_OPENFILE             1009
#define IDC_EDIT_USERNAME               1010
#define IDC_EDIT_PASSWORD               1011
#define IDC_EDIT_PASSWORD2              1013
#define IDC_EDIT_REPASSWORD             1013
#define IDC_BUTTON_BROWSER              1014
#define IDC_PROGRESS_ENCRYPT            1016
#define IDC_COMBO_USERKEYS              1018
#define IDC_BUTTON_USERMGR              1019
#define ID_POPMENU_EXIT                 32771
#define ID_POPMENU_32772                32772
#define ID_POPMENU_32773                32773
#define ID_POPMENU_SHOW                 32774
#define ID_POPMENU_KEYMANAGER           32775
#define ID_32776                        32776
#define ID_KEYMANGER                    32777
#define ID_32778                        32778
#define ID_FRIENDKEYS                   32779
#define ID_32780                        32780
#define ID_32781                        32781
#define ID_ENCRYPTFILE                  32782
#define ID_DECRYPTFILE                  32783
#define ID_POPMENU_32784                32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_32787                        32787
#define ID_32788                        32788
#define ID_POPMENU_32789                32789
#define ID_32790                        32790
#define ID_32791                        32791
#define ID_32792                        32792
#define ID_32793                        32793
#define ID_POPMENU_32794                32794
#define ID_KEYGEN                       32795
#define ID_KEYREMOVE                    32796
#define ID_KEYIMPORT                    32797
#define ID_KEYEXPORT                    32798
#define ID_32799                        32799
#define ID_EXPORT_PUBLIC                32800
#define ID_KEYPUBLIC                    32801
#define ID_POPMENU_32802                32802
#define ID_POPMENU_OPENFOLDER           32803
#define ID_POPMENU_32804                32804
#define ID_EREASEFILE                   32805

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        327
#define _APS_NEXT_COMMAND_VALUE         32806
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
